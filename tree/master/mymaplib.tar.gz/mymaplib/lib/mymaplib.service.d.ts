export declare class MymaplibService {
    constructor();
}
