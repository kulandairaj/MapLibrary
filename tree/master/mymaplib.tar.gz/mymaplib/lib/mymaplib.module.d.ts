export declare class MymaplibModule {
}
